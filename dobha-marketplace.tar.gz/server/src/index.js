// Cloudflare Worker: the Dobha API (accounts, listings, orders, wallet, live
// streaming tokens) plus item photos. The Flutter web app (mobile/build/web) is
// served by Workers assets before this runs.
import * as account from './account.js';
import * as auth from './auth.js';
import { applyCors } from './cors.mjs';
import * as google from './google.js';
import { HttpError, json } from './http.js';
import * as items from './items.js';
import * as live from './live.js';
import * as notifications from './notifications.js';
import * as orders from './orders.js';
import * as push from './push.js';
import * as social from './social.js';
import * as support from './support.js';

export { StreamClaims } from './live.js';

// [method, pattern, handler]; `:id` segments are passed to the handler in order.
const ROUTES = [
  ['POST', '/api/auth/register', auth.register],
  ['POST', '/api/auth/login', auth.login],
  ['POST', '/api/auth/google', google.googleSignIn],
  ['POST', '/api/auth/logout', auth.logout],
  ['POST', '/api/auth/forgot', account.forgotPassword],
  ['POST', '/api/auth/reset', account.resetPassword],
  ['GET', '/api/me', auth.me],
  ['PATCH', '/api/me', auth.updateMe],
  ['DELETE', '/api/me', account.deleteAccount],
  ['POST', '/api/me/password', account.changePassword],
  ['POST', '/api/me/devices', push.registerDevice],
  ['DELETE', '/api/me/devices', push.unregisterDevice],
  ['PUT', '/api/me/avatar', auth.setAvatar],
  ['DELETE', '/api/me/avatar', auth.setAvatar],

  ['GET', '/api/items', items.listItems],
  ['POST', '/api/items', items.createItem],
  ['GET', '/api/items/mine', items.myItems],
  ['GET', '/api/items/:id', items.getItem],
  ['PATCH', '/api/items/:id', items.updateItem],
  ['DELETE', '/api/items/:id', items.removeItem],
  ['POST', '/api/items/:id/like', items.toggleLike],
  ['POST', '/api/items/:id/save', items.toggleSave],
  ['GET', '/api/items/:id/comments', items.listComments],
  ['POST', '/api/items/:id/comments', items.addComment],
  ['POST', '/api/items/:id/report', items.reportItem],
  ['POST', '/api/items/:id/offers', social.makeOffer],

  ['GET', '/api/cart', social.getCart],
  ['POST', '/api/cart/checkout', orders.checkoutCart],
  ['POST', '/api/cart/:id', social.addToCart],
  ['DELETE', '/api/cart/:id', social.removeFromCart],

  ['GET', '/api/offers', social.listOffers],
  ...['accept', 'decline', 'counter', 'cancel'].map((a) => ['POST', `/api/offers/:id/${a}`, (req, env, id) => social.respondToOffer(req, env, id, a)]),

  ['GET', '/api/users', social.searchPeople],
  ['GET', '/api/users/:id', social.getProfile],
  ['GET', '/api/users/:id/followers', (req, env, id) => social.followList(req, env, id, 'followers')],
  ['GET', '/api/users/:id/following', (req, env, id) => social.followList(req, env, id, 'following')],
  ['POST', '/api/users/:id/follow', social.follow],
  ['DELETE', '/api/users/:id/follow', social.follow],

  ['GET', '/api/chats', social.listChats],
  ['GET', '/api/chats/:id', social.getChat],
  ['POST', '/api/chats/:id', social.sendMessage],
  ['GET', '/api/saved', items.savedItems],
  ['POST', '/api/uploads', items.uploadMedia],

  ['GET', '/api/orders', orders.listOrders],
  ['POST', '/api/orders', orders.createOrder],
  ['POST', '/api/orders/:id/dispatch', orders.dispatchOrder],
  ['POST', '/api/orders/:id/confirm', orders.confirmOrder],
  ['POST', '/api/orders/:id/dispute', orders.disputeOrder],
  ['POST', '/api/orders/:id/resolve', orders.resolveDispute],
  ['POST', '/api/orders/:id/review', social.reviewOrder],
  ['GET', '/api/wallet', orders.wallet],
  ['POST', '/api/wallet/topup', orders.topUp],
  ['POST', '/api/wallet/withdraw', orders.withdraw],

  ['GET', '/api/notifications', notifications.listNotifications],
  ['GET', '/api/notifications/unread', notifications.unreadCount],
  ['POST', '/api/notifications/read', notifications.markRead],

  ['GET', '/api/support', support.myRequests],
  ['POST', '/api/support', support.createRequest],

  ['GET', '/api/admin/disputes', orders.listDisputes],
  ['GET', '/api/admin/support', support.listOpen],
  ['POST', '/api/admin/support/:id/reply', (req, env, id) => support.answer(req, env, id, 'reply')],
  ['POST', '/api/admin/support/:id/close', (req, env, id) => support.answer(req, env, id, 'close')],
  ['GET', '/api/admin/reports', items.listReports],
  ['POST', '/api/admin/items/:id/remove', (req, env, id) => items.moderateItem(req, env, id, 'remove')],
  ['POST', '/api/admin/items/:id/dismiss', (req, env, id) => items.moderateItem(req, env, id, 'dismiss')],

  ['GET', '/api/rooms', live.rooms],
  ['GET', '/api/token', live.token],
].map(([method, pattern, handler]) => [method, new RegExp(`^${pattern.replaceAll(':id', '([\\w-]+)')}$`), handler]);

async function handle(request, env) {
  const { pathname } = new URL(request.url);
  const media = /^\/(media|photos)\/(.+)$/.exec(pathname);
  if ((request.method === 'GET' || request.method === 'HEAD') && media) {
    return items.serveMedia(request, env, decodeURIComponent(media[2]));
  }
  for (const [method, re, handler] of ROUTES) {
    const m = re.exec(pathname);
    if (m && method === request.method) return handler(request, env, ...m.slice(1));
  }
  return json({ error: 'Not found' }, 404);
}

export default {
  async fetch(request, env, ctx) {
    if (request.method === 'OPTIONS') {
      return applyCors(request, env, new Response(null, { status: 204 }));
    }
    let res;
    try {
      res = await handle(request, env);
    } catch (e) {
      if (e instanceof HttpError) {
        res = json({ error: e.message }, e.status);
      } else {
        console.error(e);
        res = json({ error: 'Something went wrong, please try again' }, 500);
      }
    }
    // A change may have written notifications or chat messages; push them after responding.
    if (request.method !== 'GET' && request.method !== 'HEAD' && res.ok) {
      ctx.waitUntil(push.sendPending(env).catch((e) => console.error('Push failed', e)));
    }
    return applyCors(request, env, res);
  },

  async scheduled(event, env, ctx) {
    ctx.waitUntil(Promise.all([items.cleanup(env), push.skipStale(env)]));
  },
};
